#!/bin/bash
# Copyright 2021  Binbin Zhang
#                 Menglong Xu

. ./path.sh


num_keywords=1

config=conf/general_cnn_dilation.yaml
norm_mean=true
norm_var=true
gpus="0"

checkpoint=
dir=exp 

num_average=30
score_checkpoint=$dir/avg_${num_average}.pt

download_dir=./data/local # your data dir
noise_lmdb=
reverb_lmdb=
inference_single=False
single_wav="/home/sunjian.mrouge/kws_hhz/data/local/df58f935-2f37-4a7e-8e56-b7cba435086b.wav"
label=0
. parse_options.sh || exit 1;

set -euo pipefail


if [ $inference_single == True ]; then
  echo "inference single wav"
  result_dir=$dir/test_$(basename $score_checkpoint)
  mkdir -p $result_dir
  python score_new.py \
    --config $dir/config.yaml \
    --single_inference \
    --test_data $single_wav  \
    --label $label \
    --checkpoint $score_checkpoint \
    --score_file $result_dir/score.txt \
    --num_workers 8
else 
  echo "inference multi wav"
  result_dir=$dir/test_$(basename $score_checkpoint)
  mkdir -p $result_dir
  python score_new.py \
    --config $dir/config.yaml \
    --test_data data/test/data.list  \
    --checkpoint $score_checkpoint \
    --score_file $result_dir/score.txt \
    --num_workers 8 \
    --batch_size 256
fi


